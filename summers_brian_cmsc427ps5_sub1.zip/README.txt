CMSC427 Spring 2015 Problem Set 5
Author: Brian Summers summers.brian.cs@gmail.com
110656609
4/21/15

This project fulfills the requirements for problem set 5,
including a greyscale function, correlation function,
Gaussian filter function, sharpening filter function,
and resizing function.

The project was developed in c++ using Visual Studio. 
After building the project, to run the code and provide
input, from the command line run something like
"ps5 inputFilname outputFilename" and the program will
prompt you for input to the funtions.